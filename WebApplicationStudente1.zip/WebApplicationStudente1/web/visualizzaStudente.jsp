

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@ page import="beans.Universitabean, java.util.List, java.util.Iterator" %>

<!--%@ page import = "test.FindAuthor" %-->
<!DOCTYPE html>
<html>
    <head>
        <title> Visualizza studente </title>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        



        
    </head>
    <body style="font-family: Verdana; font-size: large; color: #112244;">
                <h1>Esempio d'uso di <i>JavaBean</i></h1> 
        <h2>Cerca il cognome nel database</h2>
         <form name="f1" action="Studente" method="post">
            <table bgcolor=GRAY 
                   style="font-family: Verdana; font-size: large;
                   font-weight: bold; padding: 28px; ">
                <tr>
                    <td style="color:white; width:100px;">
                        Cognome:
                    </td>
                    <td style="color:#008000; width:250px;">
                        <input type=text name="tcognome" size="26" >
                    </td>
                    <td>
                        <input type="submit" name="azione" value="bcerca"
                               style="font-family: Verdana; font-size: large;
                               font-weight: bold; padding: 8px;">
                    </td>
                </tr>
                </table>
             </form>
             <%
    List<Universitabean> lista = (List<Universitabean> )request.getAttribute("risultatoRicerca");

    if (lista != null && !lista.isEmpty()) {
        for (Universitabean u : lista) {
%>
            <p>
                <strong>Nome:</strong> <%= u.toString() %><br>
               
                <hr>
            </p>
<%
        }
    } else {
%>
        <p>Nessun risultato trovato per il cognome inserito.</p>
<%
    }
%>

             
       

        <p><a href="/WebApplicationStudente1/index.html">Indietro</a></p>
    </body>
</html>





