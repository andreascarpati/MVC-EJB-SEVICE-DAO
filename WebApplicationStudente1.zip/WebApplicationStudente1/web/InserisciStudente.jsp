<%-- 
    Document   : InserisciStudente
    Created on : 3 nov 2025, 09:01:43
    Author     : andre
--%>

<!DOCTYPE html>
<html lang="en">
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container-fluid">
  <h1>inserimento dati</h1>
     <form name="fins" action="Studente" method="post">

  <div class="row">
    <div class="col-sm-1" style="background-color:lavender;">Matricola<input type="text" name="tmatricola" value=""/></div>
    <div class="col-sm-1" style="background-color:lavender;">nome<input type="text" name="tnome" value=""/></div>
    <div class="col-sm-1" style="background-color:lavender;">cognome<input type="text" name="tcognome" value=""/></div>
    <div class="col-sm-1" style="background-color:lavender;">datanascita<input type="text" name="tdata" value=""/></div>
    <div class="col-sm-1" style="background-color:lavender;">dataiscr<input type="text" name="tdataiscr" value=""/></div>
        
  </div>
         <div class="row">
          <div class="col-sm-1" style="background-color:lavender;"><input type="submit" name="azione" value="inserisci"/></div>
          </div>
  </form>
</div>
        
<p>
     <%
             Integer chiaveOggetto = (Integer) request.getAttribute("chiaveInserita");        
// 1. Recupera l'oggetto ed esegui il cast alla classe wrapper Integer
    

   // 2. Verifica che non sia null per evitare NullPointerException durante l'unboxing
   int key = (chiaveOggetto != null) ? chiaveOggetto : 1; 
%>
</p>
<p>Studente inserito n: ${chiaveInserita}</p>
                
 

  <p><a href="/WebApplicationStudente1/index.html">Indietro</a></p>

    

         
      
      
        
     

         
             
           
        
 
            
               
             
           
            
             
    </body>
</html>
