
package dao;

import java.sql.*; 
//datasource
public class DatabaseConnection {
	//memorizzo in istance riff---del oggetto
	private static DatabaseConnection instance; 
	private final String url = "jdbc:mysql://localhost:3306/esempio30_lp"; 
	private final String user = "ecampus";
	private final String password = "ecampus"; 
	private DatabaseConnection() { 
		try { Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			throw new RuntimeException("Driver JDBC non trovato", e); 
			} 
		}
	public static synchronized DatabaseConnection getInstance() { 
		if (instance == null) { 
			instance = new DatabaseConnection();
			} return instance;
			} 
	public Connection getConnection() throws SQLException { 
		return DriverManager.getConnection(url, user, password); 
		}
}