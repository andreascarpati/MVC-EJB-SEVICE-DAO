package dao;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import beans.Universitabean;//Universita
import javax.ejb.Local;
//studente
//scritto
@Local
public interface IDao <T>{
	
        
	public Connection getConnection() throws SQLException;
         public List<T> getRisultato(T entity);
	public int insertRow(T entity);

	List<T> findAll() throws SQLException;


	public boolean exists(T entity);

	

	}

