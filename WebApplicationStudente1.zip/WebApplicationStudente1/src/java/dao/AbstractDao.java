package dao;

import dao.IDao;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;


//import Studente;
 

public abstract class AbstractDao<T> implements IDao<T>{ 
public Connection getConnection() throws SQLException{
    
    
	return DatabaseConnection.getInstance().getConnection();
	}
	
	protected  String processaEccezione(SQLException ex) {
		 StringBuilder sb = new StringBuilder();
		    System.err.println("\n*** SQLException caught ***\n");
		    SQLException e = ex;
		    while (e != null) {
		        // stampa le info su stderr o costruisci il messaggio
		        System.err.println("SQLState: " + e.getSQLState());
		        System.err.println("Message:  " + e.getMessage());
		        e.printStackTrace();
		        System.err.println();
		        sb.append("SQLState: ").append(e.getSQLState()).append("\n");
		        sb.append("Message: ").append(e.getMessage()).append("\n\n");
		        e = e.getNextException(); // qui uso 'e', non 'ex'
		    }
		    return sb.toString();
	}
	
@Override
	public abstract List<T>findAll() throws SQLException ;

    @Override
    public abstract List<T> getRisultato(T entity) ;
   

    @Override
    public abstract int insertRow(T entity) ;
     

    @Override
    public boolean exists(T entity) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

	
	
	



	
}
