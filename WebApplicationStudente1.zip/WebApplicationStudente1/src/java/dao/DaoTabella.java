package dao;



import beans.Universitabean;

import java.util.*;
import java.sql.*;
import javax.ejb.Stateless;

   

@Stateless
public class DaoTabella extends AbstractDao <Universitabean> implements IDao<Universitabean>  {
    public static final String DB_URL = "jdbc:mysql://localhost:3306/";
    public static final String DB_NAME = "esempio30_lp";
    public static final String DB_USER = "ecampus";
    public static final String DB_PASSWORD = "ecampus";
    

    
    /**
     *
     */
    
    public  DaoTabella() {
            // default constructor
       
    }
    public List<Universitabean> getRisultato(Universitabean c) {
        

        String sql="SELECT `matricola`, `nome`, `cognome`, `data`, `annoiscrizione` FROM `studenti` WHERE `cognome`=?";
        List<Universitabean> al = new ArrayList<>();
        try (Connection conn = getConnection();
           
            PreparedStatement pr = conn.prepareStatement(sql)){
            
            pr.setString(1, c.getCognome());
                    
            ResultSet rs;
           
            rs = pr.executeQuery();
           
            while (rs.next()) {
                
                Universitabean s=new Universitabean();
               
                s.setMatricola(rs.getString("matricola"));
                s.setNome(rs.getString("nome"));
                s.setCognome(rs.getString("cognome"));
                s.setData(rs.getString("data"));
                s.setDataiscr(rs.getString("annoiscrizione"));
                al.add(s);
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            controllaEccezione(ex);
        }
        return al;
        
        
    }

   
    


        @Override
public List<Universitabean> findAll() throws SQLException {
    List<Universitabean> lista = new ArrayList<>();
    String sql = "SELECT * FROM studenti";
    try (Connection conn = getConnection();
         PreparedStatement st = conn.prepareStatement(sql);
         ResultSet rs = st.executeQuery()) {
        while (rs.next()) {
            Universitabean s = new Universitabean();
            s.setMatricola(rs.getString("matricola"));
            s.setNome(rs.getString("nome"));
            s.setCognome(rs.getString("cognome"));
            s.setData(rs.getString("datanas"));
            s.setDataiscr(rs.getString("anno_iscrizione"));
            lista.add(s);
        }
    }
    return lista;
}
    

  

    


@Override
public boolean exists(Universitabean entity) {
    String sql = "SELECT COUNT(*) FROM studenti WHERE matricola = ?";
    try (Connection con = getConnection();
         PreparedStatement st = con.prepareStatement(sql)) {
        st.setString(1, entity.getMatricola());
        ResultSet rs = st.executeQuery();
        if (rs.next()) {
            return rs.getInt(1) > 0;
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
    return false;
}

 

      @Override
public int insertRow( Universitabean entity) {
	int nf=0;
        String SQL_INSERT="INSERT INTO `studenti` (`matricola`, `nome`, `cognome`, `data`, `annoiscrizione`) VALUES ('?', '?', '?', '?', '?');";
          
	  try (Connection conn =getConnection();
	    PreparedStatement st = conn.prepareStatement(SQL_INSERT)) {
	       st.setString(1,entity.getMatricola());
                st.setString(2, entity.getNome());
	        st.setString(3, entity.getCognome());  // 
                st.setString(4, entity.getData());  
                 st.setString(5, entity.getDataiscr());  
	        nf = st.executeUpdate();
	        if (nf >=0) {  // una riga inserita correttamente
	           
	           return nf;   
	        }
                 
	  } catch (SQLException e) {
	         processaEccezione(e);
	    }
	 return 0;
}

    private void controllaEccezione(SQLException ex) {
        super.processaEccezione(ex);
    }

    @Override
    public Connection getConnection() throws SQLException {
        return super.getConnection(); 
    }


}