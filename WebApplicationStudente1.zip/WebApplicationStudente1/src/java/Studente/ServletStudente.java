package Studente;

import beans.Universitabean;
import java.io.IOException;
import java.util.List;
import javax.ejb.EJB;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import service.ServiceIscrittiLocal;

@WebServlet(name = "ServletStudente", urlPatterns = {"/Studente"})
public class ServletStudente extends HttpServlet {
    @EJB
    private ServiceIscrittiLocal serv;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
     
        String azione = request.getParameter("azione");
        System.out.println("serv è null? " + (serv == null));
System.out.println("serv class: " + serv.getClass().getName());

        if (azione != null) {
            if (azione.equals("inserisci")) {
                inserimento(request,response);
            } else if (azione.equals("bcerca")) {
                ricerca(request,response);
            }
        }
    }

    private void inserimento(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Universitabean u = new Universitabean();
        u.setMatricola(request.getParameter("tmatricola"));
        u.setNome(request.getParameter("tnome"));
        u.setCognome(request.getParameter("tcognome"));
        u.setData(request.getParameter("tdata"));
        u.setDataiscr(request.getParameter("tdataiscr"));
//blocco comtroller view
        int id=serv.insert(u); // ✅ USO DELL’EJB INIETTATO
    
    

    request.setAttribute("chiaveInserita", id);

request.getRequestDispatcher("InserisciStudente.jsp").forward(request, response);
return;

}
  
 



    

    private void ricerca(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String cognome = request.getParameter("tcognome");
        Universitabean Studente =new Universitabean();
        Studente.setCognome(cognome);
        try{
          List <Universitabean> risultato =serv.LeggiTabella(Studente);
    System.out.println(">>> Chiamata completata");


        // usa risultato come vuoi
        
        request.setAttribute("risultatoRicerca", risultato); // passa la lista alla view
 
    RequestDispatcher rd = request.getRequestDispatcher("/visualizzaStudente.jsp");
    rd.forward(request, response);
           
    
    
      
        }
    catch (Exception e) {
    e.printStackTrace();
   }
 }
}
 


