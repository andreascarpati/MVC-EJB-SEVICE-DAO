package beans;


import java.util.ArrayList;
import java.util.List;





public class Universitabean implements Comparable<Universitabean>{	

        private String matricola;
	private String nome;
	private String cognome;
	private String data;
        private String dataiscr;

    public Universitabean() {
    }


	public void setMatricola(String m) {
		this.matricola = m;
	}

    public String getMatricola() {
        return matricola;
    }
        
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getCognome() {
		return cognome;
	}
	public void setCognome(String cognome) {
		this.cognome = cognome;
	}
	
	public void setData(String Data) {
		this.data=data;
	}
	
	public String getData() {
		return data;
	}

    public String getDataiscr() {
        return dataiscr;
    }
	public void setDataiscr(String dataiscr) {
         this.dataiscr=dataiscr;
    }
	


	
	
	
	@Override
	public int compareTo(Universitabean s) {
	    int cmp = this.nome.compareToIgnoreCase(s.nome);
	
	    return cmp;
	}


    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Studente{");
        sb.append("matricola=").append(this.getMatricola()).append("\n");
        sb.append("nome=").append(this.getNome()).append("\n");
        sb.append(" cognome=").append(this.getCognome()).append("\n");
        sb.append("data=").append(this.getData()).append("\n");
        sb.append("dataiscr=").append(this.getDataiscr()).append("\n");
        
        return sb.toString();
    }

    
        
        
	
}
