/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package service;

import beans.Universitabean;
import dao.DaoTabella;
import dao.IDao;
import java.sql.SQLException;
import java.util.List;
import javax.ejb.EJB;
import javax.ejb.Stateless;

/**
 *
 * @author andre
 */

@Stateless
public class ServiceIscritti implements ServiceIscrittiLocal {
   
    /**
     *
     * @param c
     * @return
     */
     @EJB
    private IDao daoiscr;
    @Override
    public List<Universitabean> LeggiTabella(Universitabean c) {
       
          List<Universitabean> risultato;
          
          System.out.println(">>> Entrato in LeggiTabella");
System.out.println("daoiscr è null? " + (daoiscr == null));
          
          risultato=daoiscr.getRisultato(c);
        return risultato;
        
  
}
    @Override
    public int  insert(Universitabean c) {
       
            
            return daoiscr.insertRow(c);
            
     
    
    
    }

   

}